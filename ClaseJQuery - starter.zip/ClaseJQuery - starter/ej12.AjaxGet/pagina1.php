<?php

$legajo = $_GET['legajo'];
$nombre = $_GET['nombre'];


sleep(5);

echo "Legajo: ".$legajo." Nombre: ".$nombre;

?>