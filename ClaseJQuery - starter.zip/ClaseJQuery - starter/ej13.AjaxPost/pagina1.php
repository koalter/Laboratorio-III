<?php

$legajo = $_POST['legajo'];
$nombre = $_POST['nombre'];


sleep(5);

echo "Legajo: ".$legajo." Nombre: ".$nombre;

?>