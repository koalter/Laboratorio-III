<?php

sleep(5);

echo "Hola Mundo";

?>